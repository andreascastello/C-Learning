#ifndef STRUCT_H_INCLUDED
#define STRUCT_H_INCLUDED

typedef struct
{
    int x;
    int y;
}
Coordonnees;

#endif // STRUCT_H_INCLUDED
