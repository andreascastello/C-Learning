#include <stdio.h>
#include <math.h>

#define MIN 1
#define MAX 2

float calculerMoyenne   ( float _tab [] , int _nbElements );
float calculerVariance  ( float _tab [] , int _nbElements , float _moy );
float calculerEcartType ( float _variance);
float determinerMinMax  ( float _tab [] , int _nbElements , int info );

int main (int argc, char** argv)
 {
  float tab [10];
  short cpt;

  for (cpt=0; cpt<10; cpt++)
   {
    printf ("Saisissez la note numero %d : ", cpt);
    scanf ("%f", &(tab[cpt]) );
   }

  printf ("\n");

  float moyenne  = calculerMoyenne   ( tab, 10 );
  float variance = calculerVariance  ( tab, 10 , moyenne);

  printf ("La moyenne est         : %.2f\n", moyenne );
  printf ("La variance est        : %.2f\n", variance);
  printf ("L'ecart-type est       : %.2f\n", calculerEcartType ( variance ));
  printf ("La valeur minimale est : %.2f\n", determinerMinMax ( tab, 10 , MIN ));
  printf ("La valeur maximale est : %.2f\n", determinerMinMax ( tab, 10 , MAX ));

  return 0;
 }

float calculerMoyenne   ( float _tab [] , int _nbElements )
 {
  float moy = 0;
  short cpt;

  for (cpt=0; cpt<_nbElements; cpt++)
   moy += _tab[cpt];

  return moy / _nbElements;
 }

float calculerVariance  ( float _tab [] , int _nbElements , float _moy )
 {
  float variance = 0;
  short cpt;

  for (cpt=0; cpt<_nbElements; cpt++)
   variance += pow ( _tab[cpt] - _moy , 2 );

  return variance / _nbElements;
 }

float calculerEcartType ( float _variance )
 {
  return sqrt ( _variance );
 }

float determinerMinMax ( float _tab [] , int _nbElements , int info )
 {
  float res = _tab[0];
  short cpt;

  for (cpt=1; cpt<_nbElements; cpt++)
   {
    if ( ( info == MIN && res > _tab[cpt] ) || ( info == MAX && res < _tab[cpt] ) )
     res = _tab[cpt];
   }

  return res;
 }
