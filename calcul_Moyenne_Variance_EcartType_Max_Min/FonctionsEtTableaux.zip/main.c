#include <stdio.h>
#include <math.h>

float calculerMoyenne   ( float _tab [] , int _nbElements );
float calculerVariance  ( float _tab [] , int _nbElements );
float calculerEcartType ( float _tab [] , int _nbElements );
float determinerMinimum ( float _tab [] , int _nbElements );
float determinerMaximum ( float _tab [] , int _nbElements );

int main (int argc, char** argv)
 {
  float tab [10];
  short cpt;

  for (cpt=0; cpt<10; cpt++)
   {
    printf ("Saisissez la note numero %d : ", cpt);
    scanf ("%f", &(tab[cpt]) );
   }

  printf ("\n");

  printf ("La moyenne est         : %.2f\n", calculerMoyenne   ( tab, 10 ));
  printf ("La variance est        : %.2f\n", calculerVariance  ( tab, 10 ));
  printf ("L'ecart-type est       : %.2f\n", calculerEcartType ( tab, 10 ));
  printf ("La valeur minimale est : %.2f\n", determinerMinimum ( tab, 10 ));
  printf ("La valeur maximale est : %.2f\n", determinerMaximum ( tab, 10 ));

  return 0;
 }

float calculerMoyenne   ( float _tab [] , int _nbElements )
 {
  float moy = 0;
  short cpt;

  for (cpt=0; cpt<_nbElements; cpt++)
   moy += _tab[cpt];

  return moy / _nbElements;
 }

float calculerVariance  ( float _tab [] , int _nbElements )
 {
  float variance = 0;
  float moy      = calculerMoyenne   ( _tab , _nbElements );
  short cpt;

  for (cpt=0; cpt<_nbElements; cpt++)
   variance += pow ( _tab[cpt] - moy , 2 );

  return variance / _nbElements;
 }

float calculerEcartType ( float _tab [] , int _nbElements )
 {
  return sqrt (calculerVariance  ( _tab , _nbElements ) );
 }

float determinerMinimum ( float _tab [] , int _nbElements )
 {
  float min = _tab[0];
  short cpt;

  for (cpt=1; cpt<_nbElements; cpt++)
   {
    if ( min > _tab[cpt] )
     min = _tab[cpt];
   }

  return min;
 }

float determinerMaximum ( float _tab [] , int _nbElements )
 {
  float max = _tab[0];
  short cpt;

  for (cpt=1; cpt<_nbElements; cpt++)
   {
    if ( max < _tab[cpt] )
     max = _tab[cpt];
   }

  return max;
 }
